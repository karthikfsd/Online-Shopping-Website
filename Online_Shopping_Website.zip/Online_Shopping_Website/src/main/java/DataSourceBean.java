
public class DataSourceBean {
	
	private final String userName = "root";
	private final String password = "root";
}
